% plot(h6_1(:,30))
% % scatter(r(:,1),r(:,2))
sound(x6(:,1),fs)




